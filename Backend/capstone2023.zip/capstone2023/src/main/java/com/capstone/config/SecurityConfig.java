package com.capstone.config;


public class SecurityConfig {

}
