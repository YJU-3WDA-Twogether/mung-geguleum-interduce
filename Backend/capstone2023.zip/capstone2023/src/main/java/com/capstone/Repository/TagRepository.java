package com.capstone.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capstone.Entity.Tag;

public interface TagRepository extends JpaRepository<Tag , Long>{

}
